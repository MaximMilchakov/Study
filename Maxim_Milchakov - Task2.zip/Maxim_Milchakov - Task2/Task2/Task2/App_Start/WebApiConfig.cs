﻿using System.Data.Entity;
using System.Web.Http;
using Unity;
using Task2.Controllers;
using Task2.Repositories;
using Task2.Interfaces;
using System.Web.Http.Cors;
using Unity.Injection;
using Unity.Lifetime;
using Task2.NorthwindDbModel;

namespace Task2
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            var cors = new EnableCorsAttribute("*", "*", "*");
            config.EnableCors(cors);

            var container = new UnityContainer();
            container.RegisterType<IProductsRepository, ProductsRepository>();
            container.RegisterType<ISuppliersRepository, SuppliersRepository>();
            container.RegisterType<ICategoriesRepository, CategoriesRepository>();
            container.RegisterType<DbContext, NorthwindEntitiesContext>(
                          new ContainerControlledLifetimeManager(),
                          new InjectionConstructor());

            config.DependencyResolver = new UnityResolver(container);
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
