﻿using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Http;
using System.Web.Http.Description;
using Task2.Interfaces;
using Task2.NorthwindDbModel;

namespace Task2.Controllers
{
    public class ProductsController : ApiController
    {
        private IProductsRepository _repository;

        public ProductsController()
        { }

        public ProductsController(IProductsRepository repository)
        {
            _repository = repository;
        }

        // GET: api/Products
        public IQueryable<Products> GetProducts()
        {
            return _repository.GetAllProducts();
        }

        // GET: api/Products/5
        [ResponseType(typeof(Products))]
        public IHttpActionResult GetProducts(int id)
        {
            var product = _repository.GetProductByID(id);
            if (product == null)
                return NotFound();

            return Ok(product);
        }

        // PUT: api/Products/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutProducts(int id, Products product)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (id != product.ProductID)
                return BadRequest();

            try
            {
                _repository.EditProduct(product);
            }
            catch (DbUpdateConcurrencyException)
            {
                var productByID = _repository.GetProductByID(id);
                if (productByID == null)
                    return NotFound();
                return Conflict();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Products
        [ResponseType(typeof(Products))]
        public IHttpActionResult PostProducts(Products product)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _repository.AddProduct(product);

            return CreatedAtRoute("DefaultApi", new { id = product.ProductID }, product);
        }

        // DELETE: api/Products/5
        [ResponseType(typeof(Products))]
        public IHttpActionResult DeleteProducts(int id)
        {
            var product = _repository.GetProductByID(id);
            if (product == null)
                return NotFound();

            _repository.DeleteProduct(product);

            return Ok(product);
        }
    }
}