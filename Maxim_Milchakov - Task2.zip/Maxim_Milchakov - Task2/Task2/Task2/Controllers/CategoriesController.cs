﻿using System.Linq;
using System.Web.Http;
using Task2.Interfaces;
using Task2.NorthwindDbModel;

namespace Task2.Controllers
{
    public class CategoriesController : ApiController
    {
        private ICategoriesRepository _repository;

        public CategoriesController()
        { }

        public CategoriesController(ICategoriesRepository repository)
        {
            _repository = repository;
        }

        // GET: api/Categories
        public IQueryable<Categories> GetCategories()
        {
            return _repository.GetAllCategories();
        }
    }
}