﻿using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Http;
using System.Web.Http.Description;
using Task2.Interfaces;
using Task2.NorthwindDbModel;

namespace Task2.Controllers
{
    public class SuppliersController : ApiController
    {
        private ISuppliersRepository _repository;

        public SuppliersController()
        { }

        public SuppliersController(ISuppliersRepository repository)
        {
            _repository = repository;
        }

        // GET: api/Suppliers
        public IQueryable<Suppliers> GetSuppliers()
        {
            return _repository.GetAllSuppliers();
        }

        // GET: api/Suppliers/5
        [ResponseType(typeof(Suppliers))]
        public IHttpActionResult GetSuppliers(int id)
        {
            var supplier = _repository.GetSupplierByID(id);
            if (supplier == null)
                return NotFound();

            return Ok(supplier);
        }

        // PUT: api/Suppliers/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSuppliers(int id, Suppliers supplier)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (id != supplier.SupplierID)
                return BadRequest();

            try
            {
                _repository.EditSupplier(supplier);
            }
            catch (DbUpdateConcurrencyException)
            {
                var supplierByID = _repository.GetSupplierByID(id);
                if (supplierByID == null)
                    return NotFound();
                return Conflict();
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Suppliers
        [ResponseType(typeof(Suppliers))]
        public IHttpActionResult PostSuppliers(Suppliers supplier)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _repository.AddSupplier(supplier);

            return CreatedAtRoute("DefaultApi", new { id = supplier.SupplierID }, supplier);
        }

        // DELETE: api/Suppliers/5
        [ResponseType(typeof(Suppliers))]
        public IHttpActionResult DeleteSuppliers(int id)
        {
            var supplier = _repository.GetSupplierByID(id);
            if (supplier == null)
                return NotFound();

            _repository.DeleteSupplier(supplier);

            return Ok(supplier);
        }
    }
}