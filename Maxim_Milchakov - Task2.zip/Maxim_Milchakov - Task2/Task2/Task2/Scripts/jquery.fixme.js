;(function ($) {
    $.fn.fixMe = function () {
        return this.each(function () {
            var $this = $(this),
                $thisFixed;

            function init() {
                $("#fixed_id").remove();
                $thisFixed = $this.clone();
                $thisFixed.find("tbody").remove().end().attr("id", "fixed_id").addClass("table-fixme-fixed").css("width", $this.innerWidth() + "px").insertBefore($this);
                resizeFixed();
            }

            function resizeFixed() {
                $thisFixed.find("tbody").remove().end().addClass("table-fixme-fixed").css("width", $this.innerWidth() + "px");
                $thisFixed.find("th").each(function (index) {
                    $(this).css({
                        "width": $this.find("th").eq(index).innerWidth() + "px",
                        "padding-left": "0px",
                        "padding-right": "0px",
                        "z-index": "9999"
                    });
                });
            }

            function scrollFixed() {
                var offset = $(this).scrollTop(),
                    tableOffsetTop = $this.offset().top,
                    tableOffsetBottom = tableOffsetTop + $this.height() - $this.find("thead").height();
                if (offset < tableOffsetTop || offset > tableOffsetBottom)
                    $thisFixed.hide();
                else if(offset >= tableOffsetTop && offset <= tableOffsetBottom && $thisFixed.is(":hidden")){
                    $thisFixed.show();
	                $(window).resize();
                }
            }

            $(window).resize(resizeFixed);
            $(window).scroll(scrollFixed);
            init();
        });
    };
})(jQuery);
