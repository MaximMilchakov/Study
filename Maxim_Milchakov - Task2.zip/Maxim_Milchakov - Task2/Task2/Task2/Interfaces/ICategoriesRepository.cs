﻿using System.Linq;
using Task2.NorthwindDbModel;

namespace Task2.Interfaces
{
    public interface ICategoriesRepository
    {
        IQueryable<Categories> GetAllCategories();
    }
}
