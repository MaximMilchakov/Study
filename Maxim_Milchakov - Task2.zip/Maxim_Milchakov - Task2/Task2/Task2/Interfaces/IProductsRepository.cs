﻿using System.Linq;
using Task2.NorthwindDbModel;

namespace Task2.Interfaces
{
    public interface IProductsRepository
    {
        void DeleteProduct(Products product);
        IQueryable<Products> GetAllProducts();
        Products GetProductByID(int id);
        void AddProduct(Products product);
        void EditProduct(Products product);
    }
}