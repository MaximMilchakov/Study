﻿using System.Linq;
using Task2.NorthwindDbModel;

namespace Task2.Interfaces
{
    public interface ISuppliersRepository
    {
        void DeleteSupplier(Suppliers supplier);
        IQueryable<Suppliers> GetAllSuppliers();
        Suppliers GetSupplierByID(int id);
        void AddSupplier(Suppliers supplier);
        void EditSupplier(Suppliers supplier);
    }
}