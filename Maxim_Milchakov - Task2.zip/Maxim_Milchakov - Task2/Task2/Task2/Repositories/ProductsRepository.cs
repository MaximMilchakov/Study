﻿using System;
using System.Data.Entity;
using System.Linq;
using Task2.NorthwindDbModel;
using Task2.Interfaces;

namespace Task2.Repositories
{
    public class ProductsRepository: IProductsRepository
    {
        private NorthwindEntitiesContext _db;

        public ProductsRepository(NorthwindEntitiesContext db)
        {
            _db = db;
        }

        public IQueryable<Products> GetAllProducts()
        {
            return _db.Products;
        }

        public Products GetProductByID(int id)
        {
            return _db.Products.Find(id);
        }

        public void EditProduct(Products product)
        {
            _db.Entry(product).State = EntityState.Modified;
            _db.SaveChanges();
        }

        public void AddProduct(Products product)
        {
            _db.Products.Add(product);
            _db.SaveChanges();
        }

        public void DeleteProduct(Products product)
        {
            var orderDetails = _db.Order_Details
                .Where(o => o.ProductID == product.ProductID);

            foreach (var orderDetail in orderDetails)
                _db.Order_Details.Remove(orderDetail);

            _db.Products.Remove(product);
            _db.SaveChanges();
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
                if (_db != null)
                {
                    _db.Dispose();
                    _db = null;
                }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}