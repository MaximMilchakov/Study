﻿using System;
using System.Linq;
using Task2.NorthwindDbModel;
using Task2.Interfaces;

namespace Task2.Repositories
{
    public class CategoriesRepository : ICategoriesRepository
    {
        private NorthwindEntitiesContext _db;

        public CategoriesRepository(NorthwindEntitiesContext db)
        {
            _db = db;
        }

        public IQueryable<Categories> GetAllCategories()
        {
            return _db.Categories;
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
                if (_db != null)
                {
                    _db.Dispose();
                    _db = null;
                }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}