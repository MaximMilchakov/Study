﻿using System;
using System.Data.Entity;
using System.Linq;
using Task2.NorthwindDbModel;
using Task2.Interfaces;

namespace Task2.Repositories
{
    public class SuppliersRepository : ISuppliersRepository
    {
        private NorthwindEntitiesContext _db;

        public SuppliersRepository(NorthwindEntitiesContext db)
        {
            _db = db;
        }

        public IQueryable<Suppliers> GetAllSuppliers()
        {
            return _db.Suppliers;
        }

        public Suppliers GetSupplierByID(int id)
        {
            return _db.Suppliers.Find(id);
        }

        public void EditSupplier(Suppliers suppliers)
        {
            _db.Entry(suppliers).State = EntityState.Modified;
            _db.SaveChanges();
        }

        public void AddSupplier(Suppliers suppliers)
        {
            _db.Suppliers.Add(suppliers);
            _db.SaveChanges();
        }

        public void DeleteSupplier(Suppliers supplier)
        {
            var products = _db.Products
                .Where(o => o.SupplierID == supplier.SupplierID);

            foreach (var product in products)
            {
                var orderDetails = _db.Order_Details
                    .Where(o => o.ProductID == product.ProductID);

                foreach (var orderDetail in orderDetails)
                    _db.Order_Details.Remove(orderDetail);

                _db.Products.Remove(product);
            }

            _db.Suppliers.Remove(supplier);
            _db.SaveChanges();
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
                if (_db != null)
                {
                    _db.Dispose();
                    _db = null;
                }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}